# Scoped text evidence

Deterministic calibration and a passing Parcel desk application change, not an
agent efficacy experiment. All data are fictional. Original capacity-trial scores
are unchanged. The engine is a development build, not a newly published release.

- `evidence/regression/`: installed-rule failures, repairs, wrapped alternative,
  and unassessed clipping/generated/custom-control cases, with the exact source.
- `evidence/parcel-desk/first/` and `final/`: complete raw reports and native images.
- `evidence/parcel-desk/source-first/` and `source-final/`: application source.
- `evidence/parcel-desk/comparison/index.html`: complete portable comparison.
- `evidence/parcel-desk/closeup/panel.html`: native-scale caption close-up.
- `calibration/`: original trial first/final HTML and data, replayed under the new
  rules; these observations are explicitly excluded from the frozen trial scores.
- `manifest.json`: file hashes, source commit, tested archive identity, and scope.

With that source checkout and its npm/Chromium dependencies installed, replay into
this extracted copy using `node calibration/replay.mjs /path/to/viewrule`. To render
a fresh close-up directory, run `node render-text-panel.mjs /path/to/viewrule
evidence/parcel-desk /path/to/new-closeup`. Existing original PNGs are retained;
the panel clips them in HTML and uses the reports' recorded DOM regions.
