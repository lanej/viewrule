// New calibration, never a rewrite of the archived trial's evaluator or scores.
import { readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const engine = path.resolve(process.argv[2]);
const { chromium } = await import(pathToFileURL(path.join(engine, 'node_modules/playwright/index.mjs')));
const { inspectPage } = await import(pathToFileURL(path.join(engine, 'src/checks.mjs')));
const root = import.meta.dirname;
const data = await readFile(path.join(root, 'data.js'));
let html;
const server = createServer((req,res) => {
  res.setHeader('Content-Type', req.url === '/data.js' ? 'text/javascript' : 'text/html');
  res.end(req.url === '/data.js' ? data : html);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
const captures = [];
try {
  for (const arm of ['baseline', 'preflight']) for (const stage of ['first','final']) {
    const file = `${arm}-${stage}.html`;
    html = await readFile(path.join(root, file));
    await page.goto(`http://127.0.0.1:${server.address().port}`);
    await page.evaluate(() => document.fonts.ready);
    const rule = arm === 'baseline'
      ? { id: 'row-labels', type: 'no-text-overlap', selector: '[data-item]', items: '.mobile-label' }
      : { id: 'sort-label', type: 'select-label-space', selector: '#sort' };
    const rules = [{ ...rule, tolerance: 1, severity: 'error', reason: 'Retain distinguishable mobile task labels.' }];
    const result = await page.evaluate(inspectPage, rules);
    captures.push({arm,stage,file,sourceSHA256:createHash('sha256').update(html).digest('hex'),rules,...result});
  }
  const result = { scope: 'Post-hoc calibration of archived source with new measurements; excluded from original trial scores.', browserVersion: browser.version(), captures };
  await writeFile(path.join(root, 'calibration.json'), JSON.stringify(result,null,2)+'\n');
  console.log(captures.map(c=>({arm:c.arm,stage:c.stage,findings:c.findings.length})));
} finally {await browser.close();await new Promise(r=>server.close(r));}
