import { readFile, writeFile, mkdir, cp } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const engine = path.resolve(process.argv[2]);
const { chromium } = await import(pathToFileURL(path.join(engine, 'node_modules/playwright/index.mjs')));

const root = path.resolve(process.argv[3]);
const output = path.resolve(process.argv[4]);
await mkdir(output, { recursive: true });
const reports = await Promise.all(['first', 'final'].map(async stage => {
  const report = JSON.parse(await readFile(path.join(root, stage, 'report.json')));
  const page = report.pages[0];
  await cp(path.join(root, stage, page.screenshot), path.join(output, stage + '.png'));
  return page;
}));
const panels = reports.map((page, index) => {
  const region = page.captureRegions.find(r => r.id === 'filters').box;
  const top = Math.floor(region.y) - 52;
  const native = page.metrics.textLegibility.filter(m => m.type === 'select-label-space');
  return `<section><h2>${index ? 'After · captions stay visible' : 'Before · accessible names, no visible captions'}</h2>
    <div class="crop"><img src="${index ? 'final' : 'first'}.png" style="top:-${top}px" alt="Original Parcel desk capture"/>
    <div class="outline" style="left:${region.x}px;top:${region.y-top}px;width:${region.width}px;height:${region.height}px"></div></div>
    <p class="metric">Toolbar: <b>${region.height} CSS px</b> high<br/>Selected-label deficit: <b>${Math.max(...native.map(m=>m.deficit))} CSS px</b></p></section>`;
});
const html = `<!doctype html><html lang="en"><meta charset="utf-8"><title>Parcel desk: visible filter context</title>
<style>*{box-sizing:border-box}body{margin:0;padding:28px;background:#f3f6f5;color:#17352b;font:15px/1.45 system-ui,sans-serif;width:920px}h1{margin:4px 0 8px;font-size:27px;letter-spacing:-.7px}.kicker{font-size:12px;text-transform:uppercase;letter-spacing:1.2px;font-weight:700}p{margin:0 0 20px;max-width:790px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}section{background:white;border:1px solid #b9cec4;padding:15px}h2{font-size:14px;min-height:42px;margin:0 0 14px}.crop{position:relative;width:390px;height:278px;overflow:hidden}.crop img{position:absolute;left:0;width:390px;height:auto;max-width:none}.outline{position:absolute;border:2px solid #d66b34;pointer-events:none}.metric{margin:14px 0 0;color:#3a554a;font-size:14px}.note{margin:20px 0 0;padding:14px 16px;border-left:4px solid #28664b;background:#e2ede7}footer{font-size:12px;color:#4e655a;margin-top:16px}</style>
<span class="kicker">Viewrule · actual application change</span><h1>Keep the filter context visible</h1>
<p>The same Parcel desk workspace at 390 CSS px. Both states pass the text-space contract; the change adds persistent captions, at a cost of 25 px in toolbar height.</p>
<div class="grid">${panels.join('')}</div>
<p class="note"><b>A passing check still leaves a design decision.</b> The original controls already fit. Making their meaning visible is an authored improvement; this exercise does not establish better operator performance.</p>
<footer>Original capture pixels at 1:1 CSS scale · outlines use recorded DOM regions · complete source, reports, and full-page comparison retained</footer></html>`;
await writeFile(path.join(output, 'panel.html'), html);
const browser = await chromium.launch();
try {
  const page = await browser.newPage({ viewport: {width:920,height:800},deviceScaleFactor:1 });
  await page.goto(pathToFileURL(path.join(output, 'panel.html')).href);
  await page.evaluate(()=>document.fonts.ready);
  if (!await page.locator('img').evaluateAll(images=>images.every(i=>i.complete&&i.naturalWidth===390))) throw Error('Original image failed to load');
  await page.screenshot({path:path.join(output,'parcel-captions.png'),fullPage:true});
} finally {await browser.close();}
