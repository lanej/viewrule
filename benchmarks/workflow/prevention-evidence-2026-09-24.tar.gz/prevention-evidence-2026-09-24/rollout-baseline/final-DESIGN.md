# Rollout comparison

## Task and evidence
Build a view to compare three equal-priority cohorts before expanding or holding a rollout. Every decision needs identity, current and proposed rollout, error count with request count, and guardrail status together. Seven-day history is supporting detail. Use a vertical comparison list, supplied tokens, one shared observation-window control and one shared heading. Mutation controls must be distinct from disclosure. Do not hide denominators or blocked status to compact the layout.

## Behavior and accessibility
Provide one native select #window with values 24h and 7d, initially 24h; show its value visibly in #active-window. The sample table values remain fixed for this prototype. Each row has [data-action="details"] controlling initially hidden [data-details] and reporting aria-expanded. Add [data-action="expand"] disabled for Pilot, and [data-action="hold"]. A cohort mutation writes exactly "expand Internal" or "hold Pilot", etc., using that row identity, in #action-log. Opening details or changing the observation window never mutates.

## Shared system
Use supplied tokens and a vertical comparison list. All three records are equal priority. Preserve complete source labels, denominators, statuses and readable text. Details disclose supporting evidence only. Narrow and wide initial views both retain all three records. No symmetry, viewport occupancy or generic aesthetic score is required.

## Verification
### Composition choices and review scope
The shared header owns the title, observation-window selector and active-window value. Three equal-priority articles use the same six-column summary: cohort, current rollout, proposed rollout, errors, requests and guardrail. A separate lower strip places history disclosure on the left and cohort-scoped mutations on the right. Required values remain above independently expanded history. Pilot retains explicit blocked status and a disabled Expand control.

Affected units are the shared header/control, decision summary, action strip and supporting history. Review their assembled initial 24h state at 800×900 and 1280×900 CSS px, then exercise 7d, disclosure and mutations. Existing in-page units suffice; no primitive library or separate harness is needed. Supplied tokens, 14px-or-larger labels, comparable identity typography, tabular numbers and natural row heights preserve readability. Finite-task whitespace is intentional.

Consulted Viewrule corpus 1.2.0: P-001, P-002, P-003 and E-DISCLOSURE-APG (W3C disclosure semantics). DR-003/DR-006 motivate nearby denominators and decision evidence; DR-007 supports readable native controls; DR-020 supports equal-priority headings. These task-scoped choices are not claims that cited sources tested this interface. The task defines history as supporting evidence and values as fixed synthetic samples. The adapter has no `docs` command; guide, guidance and contract are available. Rules and configuration remain unchanged.

Configured Viewrule checks cover required elements, readable type, bounded initial evidence, row overlap and peer type consistency. Application behavior is independently verified. Task relevance, appropriate spacing and visual quality still require review; no human approval is recorded.
