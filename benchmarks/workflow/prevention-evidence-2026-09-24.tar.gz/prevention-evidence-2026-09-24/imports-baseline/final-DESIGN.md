# Import retry queue

## Task and evidence
Build an operator view to compare source, processed/total records, rejected records, and retry eligibility before retrying an eligible import or inspecting problems. Error samples are supporting detail. All three imports have equal task priority. Use a vertical comparison list, existing supplied tokens, one shared heading and filter. Keep the long source name complete and readable. Only IMP-104 can be retried. Details must not retry or lose the summary. Filtering must show its active scope.

## Behavior and accessibility
Provide native select #filter with values all, IMP-104, IMP-105, IMP-106; selecting an identity shows only that import, selecting all restores three. Show the selected scope in #active-filter. Each row has button [data-action="details"] controlling its initially hidden [data-details] panel and reporting aria-expanded. Each row has [data-action="retry"]; disable it when ineligible. A valid retry writes exactly "retry IMP-104" in #action-log; do not mutate on disclosure or filtering.

## Shared system
Use supplied tokens and a vertical comparison list. All three records are equal priority. Preserve complete source labels, denominators, statuses and readable text. Details disclose supporting evidence only. Narrow and wide initial views both retain all three records. No symmetry, viewport occupancy or generic aesthetic score is required.

## Verification
### Composition choices
The shared header owns the title, native identity filter, and live selected scope. Three equally styled article rows follow vertically. Each row pairs identity and a fully wrapping source with aligned tabular record counts; its footer keeps status beside separate Details and Retry buttons. Supporting error samples expand below, never replacing the summary. Supplied tokens are retained. No charts or priority ranking are needed for this finite comparison.

The functional units are the shared header/filter and expandable decision row. Row variants are eligible, blocked with a long source, and complete; representative states are collapsed, expanded, filtered, and retry logged. Native controls, visible labels, focus outlines, aria-expanded/aria-controls, and disabled ineligible retries preserve action meaning. The implementation owns behavior verification; configured checks and screenshot inspection own initial layout evidence at 800×900 and 1280×900.

Guidance consulted: Viewrule corpus v1.2.0, P-001, P-002, P-003, and E-DISCLOSURE-APG (W3C disclosure pattern). DR-003 motivates explicit record units and denominators; DR-006 keeps comparison factors together; DR-007 preserves readable type and targets; DR-020 supports comparable peer headings. Error samples are secondary as explicitly instructed. These are task-specific choices, not claims that cited sources tested this UI. The adapter does not support the docs command; guide and schema commands remain available. No rules or protected configuration are changed.

### Evidence responsibilities
Configured Viewrule checks cover required elements, readable type, bounded initial evidence, row overlap and peer type consistency. Application behavior is independently verified. Task relevance, appropriate spacing and visual quality still require review; no human approval is recorded.
