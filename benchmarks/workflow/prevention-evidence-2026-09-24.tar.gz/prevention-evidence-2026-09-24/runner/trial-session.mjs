import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';

export async function runSession({cwd,prompt,output,maxTokens=600000,seconds=480}) {
 await mkdir(output,{recursive:true});
 const userConfig=await readFile('/account/.codex/config.toml','utf8');
 const config={project_doc_max_bytes:0,web_search:'disabled',model_reasoning_effort:'ultra',personality:'none','features.multi_agent':false,'features.memories':false,'features.apps':false};
 for(const m of userConfig.matchAll(/^\[plugins\."([^"]+)"\]/gm)) config[`plugins.${JSON.stringify(m[1])}.enabled`]=false;
 for(const m of userConfig.matchAll(/^\[mcp_servers\.([^\].]+)\]/gm)) config[`mcp_servers.${m[1]}.enabled`]=false;
 const args=['app-server',...Object.entries(config).flatMap(([k,v])=>['-c',`${k}=${JSON.stringify(v)}`])];
 const child=spawn('codex',args,{cwd,stdio:['pipe','pipe','pipe']});
 const events=[],errors=[];let serial=0,usage,threadId,turnId,finalText='',finished=false;
 const started=Date.now(),pending=new Map();
 child.stderr.on('data',d=>errors.push(String(d)));
 const send=m=>child.stdin.write(JSON.stringify(m)+'\n');
 const request=(method,params)=>new Promise((resolve,reject)=>{const id=++serial;pending.set(id,{resolve,reject});send({id,method,params});});
 const done=new Promise(resolve=>{
  const finish=async(status,extra={})=>{if(finished)return;finished=true;clearTimeout(deadline);child.kill('SIGTERM');const result={status,elapsedMs:Date.now()-started,usage:usage??null,finalText,threadId,...extra};await writeFile(path.join(output,'events.jsonl'),events.map(e=>JSON.stringify(e)).join('\n')+'\n');await writeFile(path.join(output,'stderr.log'),errors.join(''));await writeFile(path.join(output,'result.json'),JSON.stringify(result,null,2)+'\n');resolve(result);};
  const deadline=setTimeout(()=>finish('wall-time-limit'),seconds*1000);
  child.on('error',e=>finish('runner-error',{error:e.message}));
  child.on('exit',(code,signal)=>{if(!finished)finish('runner-exited',{code,signal});});
  createInterface({input:child.stdout}).on('line',line=>{
   let m;try{m=JSON.parse(line);}catch{return;}
   if(m.id!=null&&pending.has(m.id)){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);return;}
   events.push(m);
   if(m.id!=null&&m.method)send({id:m.id,error:{code:-32000,message:'Interactive requests are unavailable in this controlled trial.'}});
   if(m.method==='thread/tokenUsage/updated'){usage=m.params.tokenUsage.total;if(usage.totalTokens>maxTokens)finish('token-limit-exceeded');}
   if(m.method==='item/completed'&&m.params.item.type==='agentMessage'&&m.params.item.phase==='final_answer')finalText=m.params.item.text;
   if(m.method==='turn/completed')finish(m.params.turn.status,{turn:m.params.turn});
  });
  (async()=>{
   try{
    await request('initialize',{clientInfo:{name:'viewrule-workflow-pilot',version:'1'},capabilities:{experimentalApi:true}});send({method:'initialized',params:{}});
    const list=await request('skills/list',{cwds:[cwd],forceReload:true});
    const skillPaths=list.data.flatMap(d=>d.skills.map(s=>s.path));
    const thread=await request('thread/start',{cwd,ephemeral:true,model:'gpt-6-astra',approvalPolicy:'never',sandbox:'workspace-write',personality:'none',config:{...config,'skills.config':skillPaths.map(p=>({path:p,enabled:false}))}});
    threadId=thread.thread.id;
    const turn=await request('turn/start',{threadId,model:'gpt-6-astra',effort:'ultra',input:[{type:'text',text:prompt}],sandboxPolicy:{type:'workspaceWrite',writableRoots:[cwd],networkAccess:true}});
    turnId=turn.turn.id;
    events.push({method:'trial/settings',params:{model:thread.model,effort:'ultra',threadId,turnId,disabledSkillCount:skillPaths.length,maxTokens,seconds}});
   }catch(e){finish('runner-error',{error:e.message});}
  })();
 });
 return done;
}
if(process.argv[2]==='probe'){
 const cwd=path.resolve('../work/trial-probe');await mkdir(cwd,{recursive:true});
 const r=await runSession({cwd,output:cwd,prompt:'Reply READY. Do not use tools.',seconds:90,maxTokens:20000});
 console.log(JSON.stringify(r));
}
