import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,cp,readdir} from 'node:fs/promises';
import {execFile,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import path from 'node:path';
import {runSession} from './trial-session.mjs';
import {chromium} from './release-0.9.0-smoke/node_modules/playwright/index.mjs';

const root=path.resolve('../work/prevention-pilot-2026-09-24');
const repo=process.cwd();
const engine=path.resolve('../work/release-0.9.0-smoke/node_modules/viewrule');
const browserPath='/private/tmp/viewrule-browsers/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell';
const baseline='0b1073a15cb46f598a7a38dc6c3c92bc00910f81',treatment='6b54088daafe51ca995ee940de280f815fe679dd';
const hash=x=>createHash('sha256').update(x).digest('hex');
const json=x=>JSON.stringify(x,null,2)+'\n';
const tasks={
 imports:{title:'Import retry queue',fields:['identity','source','processed','total','rejected','status'],rows:[
  {identity:'IMP-104',source:'Vendor catalog',processed:'9,980',total:'10,000',rejected:'20',status:'Eligible',eligible:true,detail:'20 rejected rows: missing SKU'},
  {identity:'IMP-105',source:'Regional catalog with a long descriptive name',processed:'480',total:'500',rejected:'20',status:'Blocked: source authorization required',eligible:false,detail:'20 rejected rows: source authorization required'},
  {identity:'IMP-106',source:'Inventory update',processed:'1,000',total:'1,000',rejected:'0',status:'Complete',eligible:false,detail:'No rejected rows'}],
 brief:'Build an operator view to compare source, processed/total records, rejected records, and retry eligibility before retrying an eligible import or inspecting problems. Error samples are supporting detail. All three imports have equal task priority. Use a vertical comparison list, existing supplied tokens, one shared heading and filter. Keep the long source name complete and readable. Only IMP-104 can be retried. Details must not retry or lose the summary. Filtering must show its active scope.',
 controls:'Provide native select #filter with values all, IMP-104, IMP-105, IMP-106; selecting an identity shows only that import, selecting all restores three. Show the selected scope in #active-filter. Each row has button [data-action="details"] controlling its initially hidden [data-details] panel and reporting aria-expanded. Each row has [data-action="retry"]; disable it when ineligible. A valid retry writes exactly "retry IMP-104" in #action-log; do not mutate on disclosure or filtering.'},
 rollout:{title:'Rollout comparison',fields:['identity','current','proposed','errors','requests','guardrail'],rows:[
 {identity:'Internal',current:'10%',proposed:'25%',errors:'4',requests:'20,000',guardrail:'Clear',eligible:true,detail:'Seven-day errors: 1, 2, 1, 0, 3, 2, 4'},
 {identity:'Pilot',current:'5%',proposed:'10%',errors:'90',requests:'10,000',guardrail:'Blocked',eligible:false,detail:'Seven-day errors: 7, 12, 18, 24, 41, 67, 90'},
 {identity:'General',current:'1%',proposed:'5%',errors:'15',requests:'50,000',guardrail:'Clear',eligible:true,detail:'Seven-day errors: 3, 4, 6, 5, 10, 12, 15'}],
 brief:'Build a view to compare three equal-priority cohorts before expanding or holding a rollout. Every decision needs identity, current and proposed rollout, error count with request count, and guardrail status together. Seven-day history is supporting detail. Use a vertical comparison list, supplied tokens, one shared observation-window control and one shared heading. Mutation controls must be distinct from disclosure. Do not hide denominators or blocked status to compact the layout.',
 controls:'Provide one native select #window with values 24h and 7d, initially 24h; show its value visibly in #active-window. The sample table values remain fixed for this prototype. Each row has [data-action="details"] controlling initially hidden [data-details] and reporting aria-expanded. Add [data-action="expand"] disabled for Pilot, and [data-action="hold"]. A cohort mutation writes exactly "expand Internal" or "hold Pilot", etc., using that row identity, in #action-log. Opening details or changing the observation window never mutates.'}
};
const common=`Implement only index.html and, if necessary, record composition choices in DESIGN.md. TASK.md, data.js, package.json, assistance, and .ui-review/config.json and rules.json are protected inputs. Do not change them or read another trial, the source repository, transcripts, controller, or evaluator. The evaluator is outside your task. No network/package installation or external research. All data is synthetic. Work in one session; do not create subagents.
Keep all initial decision fields readable and fully visible together at 800x900 and 1280x900 CSS px. Use at least 14px computed text, visible labels and keyboard-operable native controls. No horizontal page overflow, clipped required text, or overlapping rows. All three records fit in the initial view at both sizes. Supporting detail may take more space when expanded. Whitespace is acceptable for this finite task.
Use one [data-item="IDENTITY"] article per row; each field has a descendant [data-field="FIELD"] containing exactly that supplied field value as visible text. Keep field labels outside those value elements. Use [data-field="identity"] headings of comparable font size. Keep all required field values visible while details open. The data.js file defines window.records and cannot be edited. Preserve values, units, identities and action scope.
Read the supplied review workflow in $CLAUDE_PLUGIN_ROOT/skills/review/SKILL.md. Follow the relevant guidance. The shared Viewrule adapter is already configured; use its contract/guidance/docs/guide/check commands normally. No setup or installation is needed. It runs the same released engine for every task. The app is already served at the URL in .ui-review/config.json; do not start a server.
When your first working implementation is ready, run npm run check before correcting its reported failures. This freezes the first checked implementation. You may then repair and check again within the budget. Inspect the generated screenshots with the image tool. npm run check covers configured browser rules; application behavior remains your responsibility and will be evaluated independently after the session. The same read-only browser check service is available through the adapter to avoid nested Chromium sandbox restrictions. No human approval is supplied. Finish with changes, verification, and remaining limits.`;
const starter='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Operator workspace</title><style>:root{--space:12px;--ink:#16372c;--muted:#496254;--line:#cbd8ce;--surface:#f3f7f4}*{box-sizing:border-box}body{margin:0;padding:24px;font:16px system-ui;color:var(--ink);background:white}button,select{font:inherit}main{max-width:1200px;margin:auto}</style><script src="data.js"></script><main id="workspace">Implement the comparison here.</main><output id="action-log" aria-live="polite"></output></html>';

async function evaluate(directory,task,url,browser,out){
 const observations=[];
 for(const width of [800,1280]){
  const context=await browser.newContext({viewport:{width,height:900}});const page=await context.newPage();page.setDefaultTimeout(1500);await page.goto(url);
  const failures=[];
  const record=async(label,fn)=>{try{await fn();}catch(e){failures.push({label,reason:String(e.message).slice(0,400)});}};
  await record('required-evidence',async()=>{
   for(const row of task.rows){const item=page.locator(`[data-item="${row.identity}"]`);assert.equal(await item.count(),1);
    for(const field of task.fields){const value=item.locator(`[data-field="${field}"]`);assert.equal(await value.innerText(),row[field]);assert.ok(await value.isVisible());const b=await value.boundingBox();assert.ok(b&&b.x>=0&&b.y>=0&&b.x+b.width<=width&&b.y+b.height<=900,`${row.identity}/${field} outside initial viewport`);}
   }
  });
  await record('disclosure-preserves-summary-and-action',async()=>{
   const item=page.locator('[data-item]').first(), button=item.locator('[data-action="details"]'), detail=item.locator('[data-details]');
   assert.equal(await detail.isVisible(),false);const before=await page.locator('#action-log').innerText();await button.focus();await page.keyboard.press('Enter');assert.equal(await detail.isVisible(),true);assert.equal(await button.getAttribute('aria-expanded'),'true');assert.equal(await page.locator('#action-log').innerText(),before);
   assert.ok((await detail.innerText()).includes(task.rows[0].detail));for(const field of task.fields)assert.ok(await item.locator(`[data-field="${field}"]`).isVisible());await button.click();assert.equal(await detail.isVisible(),false);
  });
  if(task===tasks.imports){
   await record('filter-scope',async()=>{await page.locator('#filter').selectOption('IMP-105');assert.equal(await page.locator('[data-item]:visible').count(),1);assert.ok(await page.locator('[data-item="IMP-105"]').isVisible());assert.match(await page.locator('#active-filter').innerText(),/IMP-105|Regional/);await page.locator('#filter').selectOption('all');assert.equal(await page.locator('[data-item]:visible').count(),3);assert.equal((await page.locator('#action-log').innerText()).trim(),'');});
   await record('retry-scope',async()=>{assert.equal(await page.locator('[data-item="IMP-105"] [data-action="retry"]').isDisabled(),true);assert.equal(await page.locator('[data-item="IMP-106"] [data-action="retry"]').isDisabled(),true);await page.locator('[data-item="IMP-104"] [data-action="retry"]').click();assert.equal((await page.locator('#action-log').innerText()).trim(),'retry IMP-104');});
  }else{
   await record('shared-window',async()=>{assert.equal(await page.locator('#window').count(),1);await page.locator('#window').selectOption('7d');assert.match(await page.locator('#active-window').innerText(),/7d/);assert.equal((await page.locator('#action-log').innerText()).trim(),'');});
   await record('mutation-scope',async()=>{assert.equal(await page.locator('[data-item="Pilot"] [data-action="expand"]').isDisabled(),true);await page.locator('[data-item="Internal"] [data-action="expand"]').click();assert.equal((await page.locator('#action-log').innerText()).trim(),'expand Internal');await page.locator('[data-item="Pilot"] [data-action="hold"]').click();assert.equal((await page.locator('#action-log').innerText()).trim(),'hold Pilot');});
  }
  await page.screenshot({path:path.join(out,`evaluated-${width}.png`),fullPage:true});observations.push({width,failures});await context.close();
 }
 return observations;
}

async function prepare(){
 await mkdir(root);await mkdir(path.join(root,'results'));
 const records=[];
 // Counterbalance the first arm across tasks; one run per arm/task is exploratory.
 for(const [taskName,arms] of [['imports',['baseline','treatment']],['rollout',['treatment','baseline']]]){
  for(const arm of arms){
   const id=`${taskName}-${arm}`,directory=path.join(root,id),assistance=path.join(directory,'assistance');await mkdir(directory);await mkdir(path.join(directory,'.ui-review'));
   execFileSync('git',['init','-q',directory]);
   await mkdir(assistance);
   const archive=execFileSync('git',['archive',arm==='baseline'?baseline:treatment,'plugins/claude-code'],{cwd:repo,maxBuffer:16*1024*1024});
   execFileSync('tar',['-x','--strip-components=2','-C',assistance],{input:archive});
   const task=tasks[taskName];await writeFile(path.join(directory,'index.html'),starter);await writeFile(path.join(directory,'data.js'),'window.records='+JSON.stringify(task.rows)+';\n');
   const taskText=`# ${task.title}\n\n${task.brief}\n\nRequired fields: ${task.fields.join(', ')}.\n\n${task.controls}\n\n${common}\n`;
   await writeFile(path.join(directory,'TASK.md'),taskText);
   await writeFile(path.join(directory,'DESIGN.md'),`# ${task.title}\n\n## Task and evidence\n${task.brief}\n\n## Behavior and accessibility\n${task.controls}\n\n## Shared system\nUse supplied tokens and a vertical comparison list. All three records are equal priority. Preserve complete source labels, denominators, statuses and readable text. Details disclose supporting evidence only. Narrow and wide initial views both retain all three records. No symmetry, viewport occupancy or generic aesthetic score is required.\n\n## Verification\nConfigured Viewrule checks cover required elements, readable type, bounded initial evidence, row overlap and peer type consistency. Application behavior is independently verified. Task relevance, appropriate spacing and visual quality still require review; no human approval is recorded.\n`);
   const rules=[{id:'required-rows',type:'visible-count',selector:'[data-item]',min:3},{id:'required-fields',type:'required-elements',selector:'[data-item]',required:task.fields.map(f=>`[data-field="${f}"]`)},{id:'readable',type:'min-font-size',selector:'main',min:14},{id:'row-overlap',type:'no-overlap',selector:'[data-item]'},{id:'peer-type',type:'peer-footprint',selector:'main',items:'[data-field="identity"]',measure:'font-size',maxCoefficientOfVariation:0.05},{id:'text-clipping',type:'no-clip',selector:'[data-field]'}].map(r=>({...r,severity:'error',reason:'Preserve the supplied comparison task at both configured widths.'}));
   await writeFile(path.join(directory,'.ui-review/rules.json'),json(rules));
   await writeFile(path.join(directory,'.ui-review/config.json'),json({version:1,baseURL:'http://127.0.0.1:1',sourcePaths:['index.html'],projectDocuments:['DESIGN.md'],accessibility:true,pages:[{name:'workspace',path:'/',ready:'main'}],viewports:[{name:'compact',width:800,height:900},{name:'wide',width:1280,height:900}]}));
   await writeFile(path.join(directory,'package.json'),json({name:'workflow-trial',private:true,type:'module',scripts:{check:'node assistance/scripts/viewrule.mjs check'}}));
   records.push({id,arm,taskName,directory});
  }
 }
 await writeFile(path.join(root,'manifest.json'),json({status:'prepared',baseline,treatment,engine:'0.9.0',engineArchiveSHA256:'0a2fe72e8d259590d146c309e664cc05484d27ce1def937e1587feab3f705fb3',model:'gpt-6-astra',reasoning:'ultra',seconds:480,maxTokens:600000,trialCount:4,repetitions:1,scheduling:'sequential, counterbalanced first arm across tasks',isolation:'Fresh ephemeral sessions; workspace-write sandbox. Read isolation is an instruction boundary, not a container security boundary. No external research, other trials, engine source or evaluator access is permitted. Protected files are hash checked.',preventionDefinition:'First invocation of configured check snapshots the source before returning findings. This is the first checked implementation, not necessarily the first edit or render.',authoringCost:'Shared task, contract and harness preparation is outside generation timing; authoring labor was not instrumented. Do not claim end-to-end savings.',createdAt:new Date().toISOString(),runnerSHA256:hash(await readFile(import.meta.filename)),sessionSHA256:hash(await readFile(new URL('./trial-session.mjs',import.meta.url))),records}));
 console.log('Prepared '+root);
}
async function run(id){
 const manifest=JSON.parse(await readFile(path.join(root,'manifest.json')));assert.equal(hash(await readFile(import.meta.filename)),manifest.runnerSHA256);assert.equal(hash(await readFile(new URL('./trial-session.mjs',import.meta.url))),manifest.sessionSHA256);
 const item=manifest.records.find(x=>x.id===id);assert.ok(item);const {directory,taskName}=item,task=tasks[taskName],out=path.join(root,'results',id);await mkdir(out);
 const browser=await chromium.launch({executablePath:browserPath,args:['--hide-scrollbars']});
 const calls=[];let active=false;
 const env={...process.env,VIEWRULE_CONFIG_DIR:path.join(directory,'global'),VIEWRULE_BROWSER_PATH:browserPath};
 const cli=args=>new Promise(resolve=>execFile(process.execPath,[path.join(engine,'bin/viewrule.mjs'),...args],{cwd:directory,env,timeout:90000,maxBuffer:8*1024*1024},(error,stdout,stderr)=>resolve({code:error?.code??0,stdout,stderr})));
 const server=createServer(async(req,res)=>{
  try{
   if(req.method==='GET'&&['/','/data.js'].includes(req.url)){res.setHeader('Content-Type',req.url.endsWith('.js')?'text/javascript':'text/html');return res.end(await readFile(path.join(directory,req.url==='/'?'index.html':'data.js')));}
   if(req.method!=='POST'||req.url!=='/command')return res.writeHead(404).end();
   let body='';for await(const chunk of req){body+=chunk;if(body.length>20000)throw new Error('Request too large');}const args=JSON.parse(body);assert.ok(Array.isArray(args)&&args.every(a=>typeof a==='string'));
   assert.ok(['check','contract','guidance','docs','guide','schema','--help','--version'].includes(args[0]),'Read-only assistance commands only');
   assert.ok(!args.some(x=>['--project','--scope','--output'].includes(x)),'Task scope cannot change');
   if(active)return res.writeHead(409).end('A check is already running');active=true;
   try{
    const before=await readFile(path.join(directory,'index.html')),started=Date.now();
    if(args[0]==='check'&&!calls.some(c=>c.command==='check'))await writeFile(path.join(out,'first-checked.html'),before);
    const result=await cli(args);const record={command:args[0],args,elapsedMs:Date.now()-started,code:result.code,sourceSHA256:hash(before)};
    if(args[0]==='check'&&[0,1].includes(result.code)){
      const output=JSON.parse(result.stdout),report=JSON.parse(await readFile(output.report));record.summary=report.summary;record.findings=report.pages.map(p=>({viewport:p.viewport.name,findings:p.findings.map(f=>({rule:f.rule,message:f.message,actual:f.actual}))}));
      const n=calls.filter(c=>c.command==='check').length;await cp(path.dirname(output.report),path.join(out,`check-${n}`),{recursive:true});
    }
    calls.push(record);await writeFile(path.join(out,'calls.json'),json(calls));res.setHeader('Content-Type','application/json');res.end(json(result));
   }finally{active=false;}
  }catch(e){res.writeHead(500).end(json({error:e.message}));}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const url=`http://127.0.0.1:${server.address().port}`;env.VIEWRULE_BASE_URL=url;
 const configPath=path.join(directory,'.ui-review/config.json'),config=JSON.parse(await readFile(configPath));config.baseURL=url;await writeFile(configPath,json(config));
 const adapter=`const r=await fetch(${JSON.stringify(url+'/command')},{method:'POST',body:JSON.stringify(process.argv.slice(2))});if(!r.ok)throw new Error(await r.text());const v=await r.json();process.stdout.write(v.stdout);process.stderr.write(v.stderr);process.exitCode=v.code;\n`;
 await writeFile(path.join(directory,'assistance/scripts/viewrule.mjs'),adapter);
 const protectedNames=['TASK.md','data.js','package.json','.ui-review/config.json','.ui-review/rules.json',...(await readdir(path.join(directory,'assistance'),{recursive:true,withFileTypes:true})).filter(e=>e.isFile()).map(e=>path.relative(directory,path.join(e.parentPath,e.name)))];
 const protectedHashes=Object.fromEntries(await Promise.all(protectedNames.map(async f=>[f,hash(await readFile(path.join(directory,f)))])));
 await writeFile(path.join(out,'protected.json'),json(protectedHashes));
 try{
  const prompt=(await readFile(path.join(directory,'TASK.md'),'utf8'))+`\n\nYour task root is ${directory}. CLAUDE_PLUGIN_ROOT is ${path.join(directory,'assistance')}. For every command, expand that variable to this literal path if it is not set. The running app URL is ${url}. Read only files in this task and engine documentation returned by the adapter. Do not inspect parent directories or engine implementation. Budget: 8 minutes and 600,000 cumulative provider-reported tokens, including cached input. Complete within those bounds.\n`;
  await writeFile(path.join(out,'prompt.txt'),prompt);console.log('Starting '+id);
  const session=await runSession({cwd:directory,prompt,output:out});
  const after=await readFile(path.join(directory,'index.html'));await writeFile(path.join(out,'final.html'),after);
  const changed=[];for(const [file,digest]of Object.entries(protectedHashes))if(hash(await readFile(path.join(directory,file)))!==digest)changed.push(file);
  const finalChecks=await cli(['check']);await writeFile(path.join(out,'final-cli.json'),json(finalChecks));
  const evaluated=await evaluate(directory,task,url,browser,out);
  let firstEvaluated=null;try{const first=await readFile(path.join(out,'first-checked.html'));await writeFile(path.join(directory,'index.html'),first);const firstDir=path.join(out,'first-evaluation');await mkdir(firstDir);firstEvaluated=await evaluate(directory,task,url,browser,firstDir);}catch(e){firstEvaluated={unavailable:e.message};}finally{await writeFile(path.join(directory,'index.html'),after);}
  const record={...item,directory:undefined,sessionStatus:session.status,elapsedMs:session.elapsedMs,usage:session.usage,protectedChanges:changed,checkCalls:calls.filter(c=>c.command==='check').length,assistanceCalls:calls.length,firstConfigured:calls.find(c=>c.command==='check')??null,finalConfiguredExit:finalChecks.code,firstIndependent:firstEvaluated,finalIndependent:evaluated,finalSourceSHA256:hash(after),browserVersion:browser.version(),unassessed:['Blind human design judgment','Generalization beyond two tasks','End-to-end setup/authoring cost','Production automatic skill selection']};
  await writeFile(path.join(out,'evaluation.json'),json(record));console.log(json(record));
 }finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
}
if(process.argv[2]==='prepare')await prepare();else if(process.argv[2]==='run')await run(process.argv[3]);else if(process.argv[2]) throw new Error('prepare | run ID');
export {evaluate,tasks,starter};
