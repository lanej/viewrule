# Import retry queue

## Task and evidence
Build an operator view to compare source, processed/total records, rejected records, and retry eligibility before retrying an eligible import or inspecting problems. Error samples are supporting detail. All three imports have equal task priority. Use a vertical comparison list, existing supplied tokens, one shared heading and filter. Keep the long source name complete and readable. Only IMP-104 can be retried. Details must not retry or lose the summary. Filtering must show its active scope.

## Behavior and accessibility
Provide native select #filter with values all, IMP-104, IMP-105, IMP-106; selecting an identity shows only that import, selecting all restores three. Show the selected scope in #active-filter. Each row has button [data-action="details"] controlling its initially hidden [data-details] panel and reporting aria-expanded. Each row has [data-action="retry"]; disable it when ineligible. A valid retry writes exactly "retry IMP-104" in #action-log; do not mutate on disclosure or filtering.

## Shared system
Use supplied tokens and a vertical comparison list. All three records are equal priority. Preserve complete source labels, denominators, statuses and readable text. Details disclose supporting evidence only. Narrow and wide initial views both retain all three records. No symmetry, viewport occupancy or generic aesthetic score is required.

## Verification
Configured Viewrule checks cover required elements, readable type, bounded initial evidence, row overlap and peer type consistency. Application behavior is independently verified. Task relevance, appropriate spacing and visual quality still require review; no human approval is recorded.

## Composition choices
The shared heading and native filter precede one vertical comparison list. Each equal-priority article uses the same identity size, spacing, and field positions (DR-017, DR-018, DR-020). Source names wrap in full; the adjacent record counts retain explicit processed, total, and rejected labels with tabular digits. Status stays next to separately scoped disclosure and retry controls. Both specified widths use the same two-column summary, with no fixed row height or hidden decision fields. A smaller-screen fallback stacks the summary. The finite three-record task does not warrant filling unused viewport space (DR-019).

This adopts guide corpus 1.2.0 P-001, P-002, and P-003 (DR-003, DR-006, DR-007), with E-DISCLOSURE-APG for native disclosure semantics and E-CARBON for supporting detail in place. These are conditional design conventions, not evidence of measured operator improvement. All six fields are primary evidence by the supplied task; problem samples alone are secondary. Reject truncating the long source or moving status into details; wrapping is the legitimate alternative. The task has no supplied component library beyond its CSS tokens.

Configured full checks and original-size screenshot inspection cover the initial component and assembled comparison at 800×900 and 1280×900. Application verification separately owns filtering, preservation of summaries during disclosure, disabled retries, and the exact action log. No rule boundaries or protected inputs are changed, and no human approval is claimed. The installed adapter does not expose the requested docs command; its returned guide and help remain available.
