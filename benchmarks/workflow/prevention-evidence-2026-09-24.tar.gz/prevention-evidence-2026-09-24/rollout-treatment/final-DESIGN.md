# Rollout comparison

## Task and evidence
Build a view to compare three equal-priority cohorts before expanding or holding a rollout. Every decision needs identity, current and proposed rollout, error count with request count, and guardrail status together. Seven-day history is supporting detail. Use a vertical comparison list, supplied tokens, one shared observation-window control and one shared heading. Mutation controls must be distinct from disclosure. Do not hide denominators or blocked status to compact the layout.

## Behavior and accessibility
Provide one native select #window with values 24h and 7d, initially 24h; show its value visibly in #active-window. The sample table values remain fixed for this prototype. Each row has [data-action="details"] controlling initially hidden [data-details] and reporting aria-expanded. Add [data-action="expand"] disabled for Pilot, and [data-action="hold"]. A cohort mutation writes exactly "expand Internal" or "hold Pilot", etc., using that row identity, in #action-log. Opening details or changing the observation window never mutates.

## Shared system
Use supplied tokens and a vertical comparison list. All three records are equal priority. Preserve complete source labels, denominators, statuses and readable text. Details disclose supporting evidence only. Narrow and wide initial views both retain all three records. No symmetry, viewport occupancy or generic aesthetic score is required.

## Verification
Configured Viewrule checks cover required elements, readable type, bounded initial evidence, row overlap and peer type consistency. Application behavior is independently verified. Task relevance, appropriate spacing and visual quality still require review; no human approval is recorded.
