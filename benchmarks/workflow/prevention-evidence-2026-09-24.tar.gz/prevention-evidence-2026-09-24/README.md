# Retained pilot evidence

One frozen session per arm/task; see the repository pilot report for limitations.
`first-checked.html` precedes configured feedback; `final.html` is the session output.
`check-0/` and `final-report/` hold matching initial-state reports and native captures.
`first-evaluation/` and `evaluated-*.png` show the independent evaluator's final action state.
The repository capture gallery retains matching initial-state before/after PNGs.

Inputs, all executed configured checks, final DESIGN.md, frozen runner/evaluator,
validation controls, source versions, resource use, and a redacted interaction ledger
are retained. Initial DESIGN.md and the common starter are constructed literally in
runner/workflow-pilot.mjs. Copied assistance captures the old/new workflow exactly,
except local path redaction and the shared adapter replacement declared in the protocol.

The ledger retains completed commands and their output, source edits, user-visible
agent messages, image paths, and browser-call outcomes. Internal reasoning, streaming
deltas, account/server diagnostics, session identifiers, and repeated browser tool
instruction text are omitted. The untouched local event logs are hashed separately;
they are not the published ledger. No authentication files are included.

Absolute account/workspace paths are replaced by /account, /workspace, and /pilot.
file-provenance.json distinguishes original and retained hashes for copied files.
Generated ledgers and this README have no original-file claim. Report provenance hashes
refer to original inputs, not redacted bytes. Do not treat redacted reports as fresh
approval evidence. The archive's checksum is provided alongside it in the repository.

These runner scripts are retained experiment records, not a supported portable harness.
To inspect an implementation, serve final.html (or first-checked.html renamed index.html)
with inputs/data.js. To reproduce the experiment, adapt the local paths and authenticated
CLI/browser environment; restore assistance from the recorded commits. Repair the known
docs-wrapper, concurrent-request, and interactive-browser harness limitations before a
new preregistered comparison, which must be reported separately from this frozen run.
