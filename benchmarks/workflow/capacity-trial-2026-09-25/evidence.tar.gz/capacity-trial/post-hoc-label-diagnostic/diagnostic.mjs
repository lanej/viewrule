// Post-hoc diagnostic, authored after inspecting the baseline mobile captures.
// It does not alter the frozen evaluator or any trial score.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createServer} from 'node:http';
import {chromium} from '../viewrule/node_modules/playwright/index.mjs';
const root='../work/complex-trial-2026-09-25';
const task=JSON.parse(await readFile(root+'/complex-trial-task.json'));
let html='';const server=createServer((req,res)=>{res.setHeader('Content-Type',req.url==='/data.js'?'text/javascript':'text/html');res.end(req.url==='/data.js'?'window.records='+JSON.stringify(task.rows)+';':html);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch();const page=await browser.newPage({viewport:{width:390,height:844}});const results=[];
try{
 for(const state of ['first-checked','final']){
  html=await readFile(root+'/results/baseline/'+state+'.html','utf8');await page.goto(`http://127.0.0.1:${server.address().port}`);
  const collisions=await page.evaluate(()=>{
   const collisions=[];
   for(const row of document.querySelectorAll('[data-item]')){
    const labels=[...row.querySelectorAll('.mobile-label')].filter(e=>e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}));
    const fragments=e=>{const walker=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);const boxes=[];let t;while((t=walker.nextNode()))if(t.textContent.trim()){const r=document.createRange();r.selectNodeContents(t);for(const b of r.getClientRects())boxes.push({text:t.textContent,...b.toJSON()});}return boxes;};
    for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++)for(const a of fragments(labels[i]))for(const b of fragments(labels[j])){const width=Math.min(a.right,b.right)-Math.max(a.left,b.left),height=Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top);if(width>1&&height>1)collisions.push({row:row.getAttribute('data-item'),first:a.text,second:b.text,width,height,firstBox:a,secondBox:b});}
   }
   return collisions;
  });results.push({state,collisions});
 }
 const out='../work/capacity-label-diagnostic';await mkdir(out,{recursive:true});await writeFile(out+'/results.json',JSON.stringify({authoredAt:new Date().toISOString(),scope:'Baseline visible mobile labels in each queue row; text-fragment DOM Range rectangles, CSS px, intersection >1px in each axis.',status:'Exploratory post-hoc diagnostic, excluded from frozen trial scores.',limits:'Text fragment rectangles approximate paint; they do not establish glyph occlusion or a universal collision criterion.',browserVersion:browser.version(),results},null,2)+'\n');console.log(results.map(r=>({state:r.state,collisions:r.collisions.length,maxOverlap:Math.max(0,...r.collisions.map(c=>c.width))})));
}finally{await browser.close();await new Promise(r=>server.close(r));}
