import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,cp,readdir,stat} from 'node:fs/promises';
import {execFile,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import path from 'node:path';
import {runSession} from './trial-session.mjs';
import {chromium} from '../viewrule/node_modules/playwright/index.mjs';

const repo=process.cwd(), root=path.resolve('../work/complex-trial-2026-09-25');
const engine=path.resolve('../work/release-0.10.0-smoke/node_modules/viewrule');
const browserPath='/private/tmp/viewrule-browsers/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell';
const task=JSON.parse(await readFile(new URL('./complex-trial-task.json',import.meta.url)));
const json=x=>JSON.stringify(x,null,2)+'\n', hash=x=>createHash('sha256').update(x).digest('hex');
const views=[{name:'compact',width:1000,height:900},{name:'wide',width:1600,height:1000},{name:'mobile',width:390,height:844}];
const fields=['identity','name','region','used','capacity','queued','projected','risk'];
const values=r=>({...r,identity:r.id,used:String(r.used),capacity:String(r.capacity),queued:String(r.queued),projected:((r.used+r.queued)/r.capacity*100).toFixed(1)+'%'});
const starter='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Regional capacity desk</title><style>:root{--ink:#192f3a;--muted:#506572;--line:#cbd5df;--surface:#f2f5f8;--accent:#245cc4;--space:12px}*{box-sizing:border-box}body{margin:0;padding:16px;font:14px system-ui;color:var(--ink);background:var(--surface)}button,select,input{font:inherit}main{max-width:1600px;margin:auto}</style><script src="data.js"></script><main id="workspace">Implement the capacity desk here.</main></html>';
const rules=[
 {id:'required-rows',type:'required-elements',selector:'#queue',required:task.rows.map(r=>`[data-item="${r.id}"]`)},
 {id:'required-fields',type:'required-elements',selector:'[data-item]',required:fields.map(f=>`[data-field="${f}"]`)},
 {id:'required-histories',type:'required-elements',selector:'#history-grid',required:task.rows.map(r=>`[data-history="${r.id}"] [data-plot]`)},
 {id:'readable',type:'min-font-size',selector:'main',min:14},
 {id:'row-overlap',type:'no-overlap',selector:'[data-item]'},
 {id:'peer-chart-area',type:'peer-footprint',selector:'#history-grid',items:'[data-plot]',measure:'area',maxCoefficientOfVariation:.05,designRules:['DR-020']},
 {id:'peer-type',type:'peer-footprint',selector:'#queue',items:'[data-field="identity"]',measure:'font-size',maxCoefficientOfVariation:.05,designRules:['DR-020']},
 {id:'text-clipping',type:'no-clip',selector:'[data-field]'}
].map(r=>({...r,severity:'error',reason:'Preserve the supplied regional capacity comparison; equal-priority history plots share an area and queue identities share a type scale.'}));
const common=`Edit only index.html. TASK.md, DESIGN.md, data.js, package.json, assistance and .ui-review configuration/rules are protected fixed inputs. Read only your task directory and documentation supplied there; no parent directories, other trials, controller/evaluator, external research, package installation, subagents or external services. These are synthetic operations. The app is already served: do not launch a server.
Read the supplied review workflow at assistance/skills/review/SKILL.md and the fixed DESIGN.md; follow applicable guidance. CLAUDE_PLUGIN_ROOT is the absolute assistance directory in this task. The shared adapter supports contract, guidance, docs, guide, schema, check, compare, --help and --version. The docs command returns paths to the exact engine documentation copied within assistance/engine-docs. No setup is needed.
A working browser is available through node assistance/scripts/browser.mjs '<JSON array of actions>'. Supported actions: {op:'open',width:1000,height:900} (reset and navigate this app only), {op:'snapshot'} (visible page text and controls), {op:'click',selector:'...'}, {op:'fill',selector:'...',value:'...'}, {op:'select',selector:'...',value:'...'}, {op:'press',selector:'...',key:'Enter'}, {op:'screenshot'} (saves a PNG and returns its path). Use valid JSON with double quotes. The browser service is serial and separate from review capture; each open resets state. Inspect saved screenshots with the image tool. Do not use unavailable browser integrations or start nested browser processes.
When the first working implementation is ready, run npm run check BEFORE repairing its findings. This freezes first checked source and evidence; it is not necessarily the first edit or render. Read findings and inspect captures, then repair and check again within the budget. Do not weaken the fixed contract. Test application interactions via the browser service: configured geometry/accessibility checks do not prove behavior or data truth. First/final evidence and annotated comparisons are retained by the controller for both workflows, including no-benefit outcomes; do not overwrite evidence or infer approval. Finish with verification and remaining limitations. Budget: 8 minutes and 600,000 cumulative provider-reported tokens including cached inputs. No human approval is supplied.`;

async function evaluate(url,browser,out){
 await mkdir(out,{recursive:true});const observations=[];
 for(const viewport of views){
  const context=await browser.newContext({viewport:{width:viewport.width,height:viewport.height}}),page=await context.newPage();page.setDefaultTimeout(1200);const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(url);
  const cases=[];const record=async(label,fn)=>{try{await fn();cases.push({label,pass:true});}catch(e){cases.push({label,pass:false,reason:String(e.message).slice(0,700)});}};
  const selected=id=>page.locator(`[data-item="${id}"] [data-select]`);
  const reset=()=>page.goto(url);
  const visibleIds=()=>page.locator('[data-item]:visible').evaluateAll(es=>es.map(e=>e.getAttribute('data-item')));
  const log=async()=> (await page.locator('#action-log').innerText()).trim();
  await record('exact-evidence-and-responsive-fit',async()=>{
   assert.equal(await page.locator('[data-item]').count(),6);
   for(const r of task.rows)for(const f of fields){const v=page.locator(`[data-item="${r.id}"] [data-field="${f}"]`);assert.equal(await v.innerText(),values(r)[f],`${r.id}/${f}`);assert.ok(await v.isVisible());const b=await v.boundingBox();assert.ok(b&&b.x>=0&&b.x+b.width<=viewport.width&&b.width>0&&b.height>0,`${r.id}/${f} exceeds horizontal viewport`);if(viewport.name!=='mobile')assert.ok(b.y>=0&&b.y+b.height<=viewport.height,`${r.id}/${f} below initial viewport`);assert.ok(await v.evaluate(e=>parseFloat(getComputedStyle(e).fontSize)>=14));}
   assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  });
  await record('six-shared-scale-histories',async()=>{
   assert.equal(await page.locator('[data-history]').count(),6);
   for(const r of task.rows){const chart=page.locator(`[data-history="${r.id}"]`),plot=chart.locator('[data-plot]');assert.ok(await plot.isVisible());assert.equal(await plot.getAttribute('viewBox'),'0 0 100 100');const points=(await chart.locator('[data-series]').getAttribute('points')).trim().split(/[\s,]+/).map(Number);assert.equal(points.length,14);for(let i=0;i<7;i++){assert.ok(Math.abs(points[2*i]-i*100/6)<.02);assert.ok(Math.abs(points[2*i+1]-(100-r.history[i]))<.02);}const text=await chart.innerText();for(const token of [r.id,'%','0','100'])assert.ok(text.includes(token),`${r.id} missing ${token}`);const b=await plot.boundingBox();assert.ok(b.width>0&&b.height>0);if(viewport.name!=='mobile')assert.ok(b.y+b.height<=viewport.height);}
  });
  await record('keyboard-disclosure-preserves-summary',async()=>{
   const item=page.locator('[data-item="CE-03"]'),button=item.locator('[data-action="details"]'),detail=item.locator('[data-details]');assert.equal(await detail.isVisible(),false);await button.focus();await page.keyboard.press('Enter');assert.equal(await detail.isVisible(),true);assert.equal(await button.getAttribute('aria-expanded'),'true');assert.ok((await detail.innerText()).includes(task.rows[2].detail));for(const f of fields)assert.ok(await item.locator(`[data-field="${f}"]`).isVisible());assert.equal(await log(),'');await button.click();assert.equal(await detail.isVisible(),false);assert.equal(await button.getAttribute('aria-expanded'),'false');
  });
  await reset();
  await record('combined-filter-scope-and-reset',async()=>{await page.locator('#region-filter').selectOption('West');await page.locator('#risk-filter').selectOption('blocked');assert.deepEqual(await visibleIds(),['SW-02']);const scope=(await page.locator('#active-scope').innerText()).toLowerCase();for(const t of ['west','blocked','1'])assert.ok(scope.includes(t));assert.equal(await page.locator('[data-history]:visible').count(),6);assert.equal(await log(),'');await page.locator('#reset-filters').click();assert.deepEqual(await visibleIds(),task.rows.map(r=>r.id).sort());for(const [id,v]of [['region-filter','all'],['risk-filter','all'],['sort','identity']])assert.equal(await page.locator('#'+id).inputValue(),v);});
  await reset();
  await record('projected-sort-and-data',async()=>{await page.locator('#sort').selectOption('projected');const expected=[...task.rows].sort((a,b)=>(b.used+b.queued)/b.capacity-(a.used+a.queued)/a.capacity||a.id.localeCompare(b.id)).map(r=>r.id);assert.deepEqual(await visibleIds(),expected);assert.equal(await log(),'');});
  await reset();
  await record('hidden-selection-remains-in-batch',async()=>{await selected('NW-01').check();await page.locator('#region-filter').selectOption('East');assert.ok((await page.locator('#selection-summary').innerText()).includes('NW-01'));assert.equal(await log(),'');assert.equal(await page.locator('#release-selected').isEnabled(),true);await page.locator('#release-selected').click();assert.equal(await log(),'release NW-01');await page.locator('#reset-filters').click();assert.equal(await selected('NW-01').isChecked(),true);await page.locator('#sort').selectOption('projected');assert.equal(await selected('NW-01').isChecked(),true);});
  await reset();
  await record('blocked-selection-cannot-be-silently-omitted',async()=>{assert.equal(await page.locator('#release-selected').isDisabled(),true);await selected('NW-01').check();await selected('NE-04').check();await page.locator('#region-filter').selectOption('West');const summary=await page.locator('#selection-summary').innerText();assert.ok(summary.includes('NW-01')&&summary.includes('NE-04'));assert.equal(await page.locator('#release-selected').isDisabled(),true);assert.equal(await log(),'');await page.locator('#reset-filters').click();for(const id of ['SW-02','NE-04'])assert.equal(await page.locator(`[data-item="${id}"] [data-action="release"]`).isDisabled(),true);await page.locator('[data-item="MT-06"] [data-action="release"]').click();assert.equal(await log(),'release MT-06');});
  await reset();
  await record('valid-batch-identities-and-data-preserved',async()=>{await selected('NW-01').check();await selected('MT-06').check();await page.locator('#release-selected').click();assert.equal(await log(),'release MT-06,NW-01');for(const id of ['NW-01','MT-06'])assert.equal(await selected(id).isChecked(),true);for(const r of task.rows)for(const f of fields)assert.equal(await page.locator(`[data-item="${r.id}"] [data-field="${f}"]`).innerText(),values(r)[f]);});
  await record('no-page-errors',async()=>assert.deepEqual(errors,[]));
  await reset();await page.screenshot({path:path.join(out,viewport.name+'.png'),fullPage:true});observations.push({viewport,cases,failures:cases.filter(c=>!c.pass)});await context.close();
 }
 await writeFile(path.join(out,'observations.json'),json(observations));return observations;
}

const config={version:1,baseURL:'http://127.0.0.1:1',sourcePaths:['index.html'],projectDocuments:['DESIGN.md'],accessibility:true,pages:[{name:'capacity',path:'/',ready:'main',captureRegions:[{id:'heading',selector:'#workspace-heading'},{id:'histories',selector:'#history-grid'},{id:'queue',selector:'#queue'}]}],viewports:views};
const names=async dir=>(await readdir(dir,{recursive:true,withFileTypes:true})).filter(e=>e.isFile()).map(e=>path.relative(dir,path.join(e.parentPath,e.name))).sort();
async function prepare(){
 await mkdir(root);await mkdir(path.join(root,'results'));const records=[];
 for(const arm of ['baseline','preflight']){
  const directory=path.join(root,arm);await mkdir(directory);await mkdir(path.join(directory,'.ui-review'));execFileSync('git',['init','-q',directory]);
  await cp(path.join(repo,'plugins/claude-code'),path.join(directory,'assistance'),{recursive:true});await cp(path.join(engine,'docs'),path.join(directory,'assistance/engine-docs'),{recursive:true});
  const skill=path.join(directory,'assistance/skills/review/SKILL.md');let text=await readFile(skill,'utf8');
  if(arm==='baseline'){text=text.replace(/For substantive rendered work, start with the short[\s\S]*?one configured run can cover\.\n\n/,'');text=text.replace(/Use the preflight to sketch[\s\S]*?changing source or intent\.\n\n/,'');}
  await writeFile(skill,text);
  await writeFile(path.join(directory,'index.html'),starter);await writeFile(path.join(directory,'data.js'),'window.records='+JSON.stringify(task.rows)+';\n');
  await writeFile(path.join(directory,'TASK.md'),`# ${task.title}\n\n${task.brief}\n\n${task.structure}\n\n${task.behavior}\n\n${task.responsive}\n\n${common}\n`);
  await writeFile(path.join(directory,'DESIGN.md'),`# ${task.title}\n\n## Decision and evidence\n${task.brief}\n\n## Behavior\n${task.behavior}\n\n## Responsive and shared system\n${task.responsive}\nUse the supplied tokens; all six plots have equal priority. Do not infer an obligation to fill extra space for this known finite six-site comparison.\n\n## Verification\nConfigured checks cover required fields, font sizes, overlap, clipping, peer plot area and identity type. Independent interaction/data checks cover the fixed semantic hooks, chart sample coordinates, filter/selection/action scope and responsive initial visibility. Pixel-level encoding truth, task relevance and overall visual quality remain human judgments. No approval is recorded.\n`);
  await writeFile(path.join(directory,'.ui-review/config.json'),json(config));await writeFile(path.join(directory,'.ui-review/rules.json'),json(rules));
  await writeFile(path.join(directory,'package.json'),json({name:'capacity-trial',private:true,type:'module',scripts:{check:'node assistance/scripts/viewrule.mjs check'}}));
  records.push({arm,directory});
 }
 const manifest={createdAt:new Date().toISOString(),cliVersion:execFileSync('codex',['--version'],{encoding:'utf8'}).trim(),protocolSHA256:hash(await readFile(new URL('./complex-trial-protocol-draft.md',import.meta.url))),controlSHA256:hash(await readFile(new URL('./complex-trial-control.html',import.meta.url))),evaluatorValidationSHA256:hash(await readFile(new URL('./complex-trial-validate.mjs',import.meta.url))),engineVersion:JSON.parse(await readFile(path.join(engine,'package.json'))).version,engineArchiveSHA256:hash(await readFile(path.resolve('../work/release-0.10.0-smoke/viewrule-0.10.0.tgz'))),assistanceCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),taskSHA256:hash(await readFile(new URL('./complex-trial-task.json',import.meta.url))),runnerSHA256:hash(await readFile(import.meta.filename)),sessionSHA256:hash(await readFile(new URL('./trial-session.mjs',import.meta.url))),model:'gpt-6-astra',reasoning:'ultra',seconds:480,maxTokens:600000,order:['baseline','preflight'],repetitions:1,records};
 await writeFile(path.join(root,'manifest.json'),json(manifest));console.log(json(manifest));
}

async function serve(directory,out,browser){
 const calls=[];let tail=Promise.resolve(),browserContext,page,shots=0;
 const env={...process.env,VIEWRULE_CONFIG_DIR:path.join(directory,'global'),VIEWRULE_BROWSER_PATH:browserPath};
 const cli=args=>new Promise(resolve=>execFile(process.execPath,[path.join(engine,'bin/viewrule.mjs'),...args],{cwd:directory,env,timeout:100000,maxBuffer:16*1024*1024},(error,stdout,stderr)=>resolve({code:typeof error?.code==='number'?error.code:error?2:0,stdout,stderr})));
 const interact=async actions=>{
  assert.ok(Array.isArray(actions)&&actions.length<=40);const results=[];
  for(const a of actions){
   if(a.op==='open'){assert.ok(Number.isInteger(a.width)&&a.width>=300&&a.width<=2000&&Number.isInteger(a.height)&&a.height>=600&&a.height<=1200);await browserContext?.close();browserContext=await browser.newContext({viewport:{width:a.width,height:a.height}});page=await browserContext.newPage();page.setDefaultTimeout(2500);await page.goto(env.VIEWRULE_BASE_URL);results.push({opened:true});continue;}
   assert.ok(page,'Open the browser first');
   if(a.op==='snapshot')results.push({text:await page.locator('body').innerText(),controls:await page.locator('button,input,select').evaluateAll(es=>es.map(e=>({tag:e.tagName,id:e.id,text:e.textContent,label:e.getAttribute('aria-label'),disabled:e.disabled,value:e.value,checked:e.checked}))) });
   else if(a.op==='screenshot'){const file=path.join(directory,`browser-${++shots}.png`);await page.screenshot({path:file,fullPage:true});results.push({file});}
   else {assert.ok(['click','fill','select','press'].includes(a.op));const l=page.locator(a.selector);if(a.op==='click')await l.click();if(a.op==='fill')await l.fill(a.value);if(a.op==='select')await l.selectOption(a.value);if(a.op==='press')await l.press(a.key);results.push({action:a.op,selector:a.selector});}
  }
  return {code:0,stdout:json(results),stderr:''};
 };
 const dispatch=async args=>{
  assert.ok(Array.isArray(args)&&args.every(a=>typeof a==='string'));
  assert.ok(['check','compare','contract','guidance','docs','guide','schema','browser','--help','--version'].includes(args[0]));
  assert.ok(!args.some(x=>['--project','--scope','--incremental'].includes(x)),'Task scope is fixed');
  if(args.includes('--url'))assert.equal(args[args.indexOf('--url')+1],env.VIEWRULE_BASE_URL,'Only this app URL is allowed');
  if(args[0]==='compare')for(const flag of ['--before','--after','--output','--annotations']){const i=args.indexOf(flag);if(i>=0)assert.ok(path.resolve(directory,args[i+1]).startsWith(directory+path.sep),'Comparison paths must stay in this task');}
  else assert.ok(!args.includes('--output'));
  const before=await readFile(path.join(directory,'index.html')),started=Date.now();
  if(args[0]==='check'&&!calls.some(c=>c.command==='check'))await writeFile(path.join(out,'first-checked.html'),before);
  let result;
  if(args[0]==='docs')result={code:0,stdout:json(Object.fromEntries([['version','0.10.0'],...Object.entries({policy:'design-rules.md',rules:'ui-review.md',detection:'ui-review-enforcement.md',defaults:'defaults.md',authoring:'rule-authoring.md'}).map(([k,v])=>[k,path.join(directory,'assistance/engine-docs',v)])])),stderr:''};
  else if(args[0]==='browser')result=await interact(JSON.parse(args[1]));
  else result=await cli(args);
  const record={command:args[0],args,elapsedMs:Date.now()-started,code:result.code,sourceSHA256:hash(before)};
  if(args[0]==='check'&&[0,1].includes(result.code)){
   const output=JSON.parse(result.stdout),report=JSON.parse(await readFile(output.report));record.summary=report.summary;record.findings=report.pages.map(p=>({viewport:p.viewport.name,findings:p.findings.map(f=>({rule:f.rule,message:f.message,actual:f.actual}))}));
   const n=calls.filter(c=>c.command==='check').length;await cp(path.dirname(output.report),path.join(out,`check-${n}`),{recursive:true});await writeFile(path.join(out,`check-${n}.html`),before);
  }
  calls.push(record);await writeFile(path.join(out,'calls.json'),json(calls));return result;
 };
 const server=createServer(async(req,res)=>{
  try{
   if(req.method==='GET'&&['/','/data.js'].includes(req.url)){res.setHeader('Content-Type',req.url.endsWith('.js')?'text/javascript':'text/html');return res.end(await readFile(path.join(directory,req.url==='/'?'index.html':'data.js')));}
   if(req.method!=='POST'||req.url!=='/command')return res.writeHead(404).end();let body='';for await(const chunk of req){body+=chunk;if(body.length>40000)throw new Error('Request too large');}
   const queued=tail.then(()=>dispatch(JSON.parse(body)));tail=queued.catch(()=>{});const result=await queued;res.setHeader('Content-Type','application/json');res.end(json(result));
  }catch(e){res.writeHead(500).end(json({error:e.message}));}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));env.VIEWRULE_BASE_URL=`http://127.0.0.1:${server.address().port}`;
 const file=path.join(directory,'.ui-review/config.json'),cfg=JSON.parse(await readFile(file));cfg.baseURL=env.VIEWRULE_BASE_URL;await writeFile(file,json(cfg));
 const wrapper=prefix=>`const r=await fetch(${JSON.stringify(env.VIEWRULE_BASE_URL+'/command')},{method:'POST',body:JSON.stringify(${prefix})});if(!r.ok)throw new Error(await r.text());const v=await r.json();process.stdout.write(v.stdout);process.stderr.write(v.stderr);process.exitCode=v.code;\n`;
 await writeFile(path.join(directory,'assistance/scripts/viewrule.mjs'),wrapper('process.argv.slice(2)'));await writeFile(path.join(directory,'assistance/scripts/browser.mjs'),wrapper('["browser",process.argv[2]]'));
 return {calls,cli,url:env.VIEWRULE_BASE_URL,close:async()=>{await tail;await browserContext?.close();await new Promise(resolve=>server.close(resolve));}};
}

async function run(arm){
 const manifest=JSON.parse(await readFile(path.join(root,'manifest.json')));for(const [key,file]of [['runnerSHA256',import.meta.filename],['sessionSHA256',new URL('./trial-session.mjs',import.meta.url)],['taskSHA256',new URL('./complex-trial-task.json',import.meta.url)]])assert.equal(hash(await readFile(file)),manifest[key]);
 const directory=manifest.records.find(r=>r.arm===arm).directory,out=path.join(root,'results',arm);await mkdir(out);
 const browser=await chromium.launch({executablePath:browserPath,args:['--hide-scrollbars']}),service=await serve(directory,out,browser);
 try{
  const protectedNames=(await names(directory)).filter(f=>!f.startsWith('.git/')&&f!=='index.html');const protectedHashes=Object.fromEntries(await Promise.all(protectedNames.map(async f=>[f,hash(await readFile(path.join(directory,f)))])));await writeFile(path.join(out,'protected.json'),json(protectedHashes));
  const prompt=(await readFile(path.join(directory,'TASK.md'),'utf8'))+`\nYour task root is ${directory}. CLAUDE_PLUGIN_ROOT is ${path.join(directory,'assistance')}. App URL: ${service.url}.\n`;
  await writeFile(path.join(out,'prompt.txt'),prompt);console.log('Starting '+arm);
  const session=await runSession({cwd:directory,prompt,output:out,seconds:manifest.seconds,maxTokens:manifest.maxTokens});
  const final=await readFile(path.join(directory,'index.html'));await writeFile(path.join(out,'final.html'),final);const changed=[];for(const [f,h]of Object.entries(protectedHashes))if(hash(await readFile(path.join(directory,f)))!==h)changed.push(f);
  const finalCheck=await service.cli(['check']);await writeFile(path.join(out,'final-cli.json'),json(finalCheck));
  if([0,1].includes(finalCheck.code))await cp(path.dirname(JSON.parse(finalCheck.stdout).report),path.join(out,'final-report'),{recursive:true});
  const finalIndependent=await evaluate(service.url,browser,path.join(out,'final-evaluation'));let firstIndependent;
  try{await writeFile(path.join(directory,'index.html'),await readFile(path.join(out,'first-checked.html')));firstIndependent=await evaluate(service.url,browser,path.join(out,'first-evaluation'));}catch(e){firstIndependent={unavailable:e.message};}finally{await writeFile(path.join(directory,'index.html'),final);}
  const annotation={version:1,title:`Capacity desk: ${arm} first checked → final`,summary:'A single fresh development session under a fixed task contract. Captions identify regions; they do not certify improvement.',callouts:[{page:'capacity',region:'heading',title:'Shared decision context',interpretation:'Inspect the title, scope and controls without treating reduced size as automatically better.'},{page:'capacity',region:'histories',title:'Six comparable histories',interpretation:'Compare common scale, labels and peer footprint. Chart sample coordinates are checked separately; screenshot geometry alone cannot establish truth.'},{page:'capacity',region:'queue',title:'Decision evidence and actions',interpretation:'Inspect complete identities, denominators, projected use, risk and action scope. Independent interaction results accompany these captures.'}]};
  await writeFile(path.join(out,'annotations.json'),json(annotation));
  const comparison=await service.cli(['compare','--before',path.join(out,'check-0/report.json'),'--after',path.join(out,'final-report/report.json'),'--output',path.join(out,'comparison'),'--annotations',path.join(out,'annotations.json'),'--image']);await writeFile(path.join(out,'comparison-cli.json'),json(comparison));
  const record={arm,sessionStatus:session.status,elapsedMs:session.elapsedMs,usage:session.usage,protectedChanges:changed,checkCalls:service.calls.filter(c=>c.command==='check').length,assistanceCalls:service.calls.length,firstConfigured:service.calls.find(c=>c.command==='check')??null,finalConfiguredExit:finalCheck.code,firstIndependent,finalIndependent,finalSourceSHA256:hash(final),comparisonExit:comparison.code,browserVersion:browser.version()};await writeFile(path.join(out,'evaluation.json'),json(record));console.log(json(record));
 }finally{await service.close();await browser.close();}
}

if(process.argv[2]==='prepare')await prepare();else if(process.argv[2]==='run')await run(process.argv[3]);
export {evaluate,task,starter,rules,config,serve,root,views};
