import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
const base=path.resolve('work/pilot');
const out=path.resolve('outputs/viewrule-pilot');
const manifest=JSON.parse(await readFile(path.join(base,'manifest.json')));
const cases=JSON.parse(await readFile('work/viewrule/benchmarks/analytical/cases.json'));
const hash=b=>createHash('sha256').update(b).digest('hex');
const rows=[];
const stateKey=o=>`${o.viewport.width}x${o.viewport.height}/${o.state}`;
for(const id of manifest.scope.plannedTrialIds){
 const trial=manifest.trials.find(t=>t.id===id);
 const dir=path.join(base,'results',id);
 const result=JSON.parse(await readFile(path.join(dir,'result.json')));
 assert.equal(result.status,'completed',`${id}: operationally incomplete`);
 assert.equal(result.exitCode,0);
 assert.ok(result.usage?.totalTokens>0&&result.usage.totalTokens<=manifest.runner.maxTokens);
 assert.ok(result.elapsedMs>0&&result.elapsedMs<=manifest.runner.wallTimeSeconds*1000);
 assert.equal(result.inputSHA256,trial.sourceSHA256);
 const before=JSON.parse(await readFile(path.join(base,'evaluations',id+'-before.json')));
 const after=JSON.parse(await readFile(path.join(base,'evaluations',id+'-after.json')));
 const transcript=(await readFile(path.join(dir,'transcript.jsonl'),'utf8')).trim().split('\n').map(l=>JSON.parse(l));
 const init=transcript.find(e=>e.kind==='server'&&e.message?.id===2)?.message.result;
 assert.equal(init.model,manifest.runner.model);
 assert.equal(init.reasoningEffort,manifest.runner.reasoning);
 assert.equal(init.thread.cliVersion,'0.153.4');
 assert.equal(hash(await readFile(path.join(dir,'before.html'))),trial.sourceSHA256);
 assert.equal(hash(await readFile(path.join(dir,'after.html'))),result.outputSHA256);
 assert.equal(after.evaluatorSHA256,manifest.evaluatorSHA256);
 assert.equal(before.evaluatorSHA256,manifest.evaluatorSHA256);
 assert.equal(after.browser,manifest.runner.browserVersion);
 const items=transcript.filter(e=>e.message?.method==='item/completed').map(e=>e.message.params.item);
 const commands=[...new Map(items.filter(i=>i.type==='commandExecution').map(i=>[i.id,i])).values()];
 const explanation=items.filter(i=>i.type==='agentMessage'&&i.phase==='final_answer').map(i=>i.text).join('\n\n');
 const failures=new Set(before.observations.flatMap(o=>o.failures.map(f=>`${stateKey(o)}/${f}`)));
 const afterFailures=after.observations.flatMap(o=>o.failures.map(f=>`${stateKey(o)}/${f}`));
 const newFailures=afterFailures.filter(f=>!failures.has(f));
 const patched=(await readFile(path.join(dir,'repair.patch'),'utf8')).replace(/^diff --git .*$/m,'diff --git a/index.html b/index.html').replace(/^--- .*$/m,'--- a/index.html').replace(/^\+\+\+ .*$/m,'+++ b/index.html');
 rows.push({id,arm:trial.arm,case:cases[trial.case-1].id,repetition:trial.repetition,status:result.status,startedModel:init.model,reasoning:init.reasoningEffort,cliVersion:init.thread.cliVersion,beforePassed:before.passed,afterPassed:after.passed,changed:result.changed,newFailures,remainingFailures:afterFailures,elapsedSeconds:result.elapsedMs/1000,usage:result.usage,providerCost:result.providerCost,commands:commands.length,imageViews:items.filter(i=>i.type==='imageView').length,recordedCommandSeconds:commands.reduce((n,c)=>n+(c.durationMs||0),0)/1000,assistanceCommands:commands.filter(c=>/viewrule\.mjs.*\bcheck\b|scripts\/impeccable.*\bdetect\b/.test(c.command)&&!c.command.includes('--help')).map(c=>({command:c.command,seconds:c.durationMs/1000,exit:c.exitCode})),inputSHA256:result.inputSHA256,outputSHA256:result.outputSHA256,explanation,patch:patched,semanticReview:null,explanationReview:null});
}
for(const group of [...new Set(rows.map(r=>r.case))]){
 const members=rows.filter(r=>r.case===group);
 assert.equal(members.length,3);
 assert.equal(new Set(members.map(r=>r.inputSHA256)).size,1);
 assert.equal(new Set(members.map(r=>manifest.trials.find(t=>t.id===r.id).promptSHA256)).size,1);
}
for(const [file,expected] of Object.entries(manifest.execution.files))assert.equal(hash(await readFile(path.join('work/viewrule',file))),expected);
const median=values=>[...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];
const arms=['baseline','impeccable','viewrule'].map(arm=>{
 const records=rows.filter(r=>r.arm===arm),seeded=records.filter(r=>!r.beforePassed),controls=records.filter(r=>r.beforePassed);
 return{arm,trials:records.length,completed:records.filter(r=>r.status==='completed').length,seededRepaired:seeded.filter(r=>r.status==="completed"&&r.afterPassed).length,seededTotal:seeded.length,regressions:records.filter(r=>r.newFailures.length).length,controlsEdited:controls.filter(r=>r.changed).length,controlsTotal:controls.length,medianSeconds:median(records.map(r=>r.elapsedSeconds)),totalInputTokens:records.reduce((n,r)=>n+(r.usage?.inputTokens||0),0),cachedInputTokens:records.reduce((n,r)=>n+(r.usage?.cachedInputTokens||0),0),totalOutputTokens:records.reduce((n,r)=>n+(r.usage?.outputTokens||0),0),providerCost:null};
});
await mkdir(out,{recursive:true});
await writeFile(path.join(out,'results.json'),JSON.stringify({kind:'exploratory-matched-pilot',generatedAt:new Date().toISOString(),scope:manifest.scope,runner:manifest.runner,execution:manifest.execution,evaluatorSHA256:manifest.evaluatorSHA256,arms,rows},null,2)+'\n');
const label={baseline:'Unaided',impeccable:'Impeccable',viewrule:'Viewrule'};
const seconds=n=>`${Math.floor(n/60)}m${Math.round(n%60).toString().padStart(2,'0')}s`;
let md='# Viewrule repair pilot — 15 September 2026\n\nNine fresh sessions compared an unaided agent, Impeccable, and Viewrule on one clean control and two seeded defects: cross-viewport identity loss and reporting context lost after filtering. Each arm ran once per case. This is an exploratory pilot, not the full 81-trial study.\n\n## Outcomes\n\n| Arm | Seeded cases repaired | New requirement failures | Clean controls edited | Median task time | Output tokens, total |\n|---|---:|---:|---:|---:|---:|\n';
for(const a of arms)md+=`| ${label[a.arm]} | ${a.seededRepaired}/${a.seededTotal} | ${a.regressions} | ${a.controlsEdited}/${a.controlsTotal} | ${seconds(a.medianSeconds)} | ${a.totalOutputTokens.toLocaleString('en-US')} |\n`;
md+='\nTimes include the complete agent task and are observations under concurrent execution. They are not controlled speed comparisons. Token totals include reasoning in the provider’s output accounting; input and cached input are recorded separately in results.json. Dollar cost was not reported.\n\n## Every trial\n\n| Case | Arm | Before | After | Source edited | Time | Input tokens | Cached input | Output tokens |\n|---|---|---|---|---|---:|---:|---:|---:|\n';
for(const r of rows)md+=`| ${r.case} | ${label[r.arm]} | ${r.beforePassed?'Pass':'Fail'} | ${r.afterPassed?'Pass':'Fail'} | ${r.changed?'Yes':'No'} | ${seconds(r.elapsedSeconds)} | ${r.usage?.inputTokens?.toLocaleString('en-US')} | ${r.usage?.cachedInputTokens?.toLocaleString('en-US')} | ${r.usage?.outputTokens?.toLocaleString('en-US')} |\n`;
md+='\n## What was held constant\n\n- GPT-6 Astra (`gpt-6-astra`), `xhigh` reasoning, Codex CLI 0.153.4; fresh session and container per trial. The service did not expose an immutable backend revision.\n- Identical source and task bytes for each case across arms; immutable requirements and arm-specific assistance.\n- Pinned Chromium 151.0.7922.34 at 1280×900 and 3840×2160, before and after the filter action.\n- Ten-minute and 1,000,000 cumulative input-plus-output-token limits; same CPU/memory limits; three concurrent trials per group.\n- A separately frozen evaluator, inaccessible to repair agents, checked preserved data, labels, context, readable type, numeric proximity, filter state, and cross-viewport identities.\n\n## Limits\n\nThere is one run per case and arm, on synthetic tasks authored by the Viewrule project. Viewrule receives an authored contract, while the baseline does not; this measures assistance under those conditions. The shared prompt’s numeric-distance wording is less precise than the authored adjacency rule, so extra spacing edits require qualitative interpretation. A changed clean control is not automatically a regression or a false positive.\n\nAutomated passes do not certify overall design quality. Human semantic review is not recorded. Authored-contract labor and provider dollar cost are unknown. The model ID is fixed, but an immutable backend snapshot is unavailable. The original 81-trial issue remains open.\n\nAn earlier three-session clean-control group was excluded because the operating instructions ambiguously prohibited generated report files. The clarified pilot explicitly permits the tools’ normal disposable reports. Original attempts are retained separately.\n';
await writeFile(path.join(out,'report.md'),md);
await cp(path.join(base,'manifest.json'),path.join(out,'manifest.json'));
for(const r of rows){
 const dst=path.join(out,'trials',r.id);await mkdir(dst,{recursive:true});
 await cp(path.join(base,'results',r.id,'before.html'),path.join(dst,'before.html'));
 await cp(path.join(base,'results',r.id,'after.html'),path.join(dst,'after.html'));
 await writeFile(path.join(dst,'repair.patch'),r.patch);
 await writeFile(path.join(dst,'explanation.md'),r.explanation+'\n');
 await cp(path.join(base,'evidence',r.id),path.join(dst,'evidence'),{recursive:true});
 for(const stage of ['before','after'])await cp(path.join(base,'evaluations',r.id+'-'+stage+'.json'),path.join(dst,stage+'-evaluation.json'));
 const raw=await readFile(path.join(base,'results',r.id,'transcript.jsonl'),'utf8');
 const events=raw.trim().split('\n').map(JSON.parse);
 const published=[];
 for(const event of events){
  if(event.message?.method!=='item/completed')continue;
  const i=event.message.params.item;
  if(i.type==='userMessage')published.push({type:i.type,content:i.content});
  if(i.type==='agentMessage')published.push({type:i.type,phase:i.phase,text:i.text});
  if(i.type==='commandExecution')published.push({type:i.type,command:i.command,cwd:i.cwd,status:i.status,output:i.aggregatedOutput,exitCode:i.exitCode,durationMs:i.durationMs});
  if(i.type==='imageView')published.push({type:i.type,path:i.path});
 }
 await writeFile(path.join(dst,'transcript.json'),JSON.stringify({format:'completed-public-items',omitted:'Private reasoning, streaming duplicates, account and transport metadata. Original events retained locally; disposable agent /tmp images are unavailable. Independent before/after captures are included.',sourceSHA256:hash(raw),items:published},null,2)+'\n');
 const trial=manifest.trials.find(t=>t.id===r.id);
 for(const file of Object.keys(trial.protectedFiles)){
  const target=path.join(dst,'inputs',file);await mkdir(path.dirname(target),{recursive:true});await cp(path.join(base,r.id,file),target);
 }
 if(r.arm==='viewrule')await cp(path.join(base,r.id,'.ui-review/runs'),path.join(dst,'tool-reports'),{recursive:true});
}
await cp('work/viewrule/benchmarks/analytical/runner',path.join(out,'runner'),{recursive:true});
await cp('work/viewrule/scripts/run-repair-trials.mjs',path.join(out,'run-repair-trials.mjs'));
await cp(path.join(base,'evaluator.mjs'),path.join(out,'evaluator.mjs'));
await cp(path.join(base,'isolation-preflight.json'),path.join(out,'isolation-preflight.json'));
await cp('work/impeccable/LICENSE',path.join(out,'IMPECCABLE-LICENSE'));
console.log(JSON.stringify({out,arms},null,2));
