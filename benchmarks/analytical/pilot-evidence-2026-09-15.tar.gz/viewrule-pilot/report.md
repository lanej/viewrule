# Viewrule repair pilot — 15 September 2026

Nine fresh sessions compared an unaided agent, Impeccable, and Viewrule on one clean control and two seeded defects: cross-viewport identity loss and reporting context lost after filtering. Each arm ran once per case. This is an exploratory pilot, not the full 81-trial study.

## Decision

Stop after this pilot. All three arms repaired both seeded defects, with no new failures in the frozen evaluator. Viewrule showed no incremental repair benefit on these cases. The full agent tasks took **2m49s–4m55s**, including the clean controls. That is a substantial cost for a routine small-change review.

Viewrule's five check commands took **2.691–6.656 seconds** each. Its complete tasks took 3m07s–3m57s and included 19–24 shell commands and 9–12 image inspections. The difference includes model interaction, instruction reading, manual browser work, and broader verification. These observations support trying a **check first, repair only on failure** workflow. They do not establish that such a workflow improves repairs or generalize to complex real applications.

The remaining **72 prepared trials were not run**. Before expanding, demonstrate a useful repair or prevention benefit on a real task where the unaided agent struggles, and record contract-authoring effort.

## Outcomes

| Arm | Seeded cases repaired | New requirement failures | Clean controls edited | Median task time | Output tokens, total |
|---|---:|---:|---:|---:|---:|
| Unaided | 2/2 | 0 | 0/1 | 4m07s | 19,654 |
| Impeccable | 2/2 | 0 | 1/1 | 3m34s | 17,287 |
| Viewrule | 2/2 | 0 | 0/1 | 3m39s | 16,761 |

Times include the complete agent task and are observations under concurrent execution. They are not controlled speed comparisons. Token totals include reasoning in the provider’s output accounting; input totals include cached input; cached tokens are also shown as a subset in results.json. Dollar cost was not reported.

## Every trial

| Case | Arm | Before | After | Source edited | Time | Input tokens | Cached input | Output tokens |
|---|---|---|---|---|---:|---:|---:|---:|
| reference | Unaided | Pass | Pass | No | 3m44s | 302,845 | 225,664 | 5,992 |
| reference | Impeccable | Pass | Pass | Yes | 4m55s | 447,595 | 385,280 | 8,174 |
| reference | Viewrule | Pass | Pass | No | 3m07s | 464,275 | 398,208 | 4,622 |
| cross-viewport | Impeccable | Fail | Pass | Yes | 2m49s | 284,428 | 243,456 | 4,369 |
| cross-viewport | Viewrule | Fail | Pass | Yes | 3m39s | 562,081 | 491,904 | 5,553 |
| cross-viewport | Unaided | Fail | Pass | Yes | 4m28s | 291,481 | 259,968 | 7,002 |
| after-filter | Viewrule | Fail | Pass | Yes | 3m57s | 535,833 | 458,368 | 6,586 |
| after-filter | Unaided | Fail | Pass | Yes | 4m07s | 300,716 | 263,552 | 6,660 |
| after-filter | Impeccable | Fail | Pass | Yes | 3m34s | 369,203 | 307,456 | 4,744 |

## Patch observations

This is an unblinded source review by the executing assistant, not the protocol's blind semantic or explanation grading:

- The Impeccable cross-viewport and after-filter repairs only removed the hiding CSS rule. The Viewrule cross-viewport repair did the same; its after-filter repair also aligned numeric headers.
- The unaided repairs removed the hiding rules and narrowed numeric spacing.
- Impeccable modified the clean control: tighter numeric spacing, numeric header alignment, filter feedback, and button focus/hover styling. The original control passed the evaluator and the changed control also passed. The shared prose does not specify whether the 150px limit applies to adjacent values or every pair; the evaluator uses adjacent text gaps. Therefore these extra edits are not scored as a regression or false positive.
- The other two clean controls were unchanged. All patched sources preserved the synthetic records and the filter's state transition under the frozen checks.
- Every arm additionally tested a temporary four-service browser fixture, even though these selected tasks have twelve services. That verification contributes to task overhead.

## What was held constant

- GPT-6 Astra (`gpt-6-astra`), `xhigh` reasoning, Codex CLI 0.153.4; fresh session and container per trial. The service did not expose an immutable backend revision.
- Identical source and task bytes for each case across arms; immutable requirements and arm-specific assistance.
- Pinned Chromium 151.0.7922.34 at 1280×900 and 3840×2160, before and after the filter action.
- Ten-minute and 1,000,000 cumulative input-plus-output-token limits; same CPU/memory limits; three concurrent trials per group.
- A separately frozen evaluator, inaccessible to repair agents, checked preserved data, labels, context, readable type, numeric proximity, filter state, and cross-viewport identities.

## Limits

There is one run per case and arm, on synthetic tasks authored by the Viewrule project. Viewrule receives an authored contract, while the baseline does not; this measures assistance under those conditions. The shared prompt’s numeric-distance wording is less precise than the authored adjacency rule, so extra spacing edits require qualitative interpretation. A changed clean control is not automatically a regression or a false positive.

Automated passes do not certify overall design quality. Human semantic review is not recorded. Authored-contract labor and provider dollar cost are unknown. The model ID is fixed, but an immutable backend snapshot is unavailable. The original 81-trial issue remains open.

One aborted preflight-era baseline attempt was retained as an excluded failed start. An earlier three-session clean-control group was excluded because the operating instructions ambiguously prohibited generated report files. The clarified pilot explicitly permits the tools’ normal disposable reports. Original attempts are retained separately.

## Reproducibility and evidence

The engine came from Viewrule source commit `5efdc96c4818c7138dc79049bc647d8628019c2b`; the tested archive SHA-256 is `d836447f03fd7ddbc6eec572ab3cfb8cc4f940013e06187b6ff0ebb8e9e77f4b`. The same archive ran inside the pinned Viewrule image. See [results.json](results.json) and [manifest.json](manifest.json) for all outcomes, usage, hashes, image identities, and planned versus completed tasks.

The evidence bundle includes exact task/assistance bytes, before/after source and original-size captures, independent observations, normalized patches, explanations, Viewrule reports, executed runner files, and completed public transcript items. Private reasoning, account/transport metadata, and duplicate streaming events are omitted from published transcripts; each names the original transcript's SHA-256. Full original event logs remain local. Disposable agent `/tmp` images are unavailable; independent captures and retained Viewrule reports are included. No account login file is in the bundle.

Validation: all nine selected sessions completed inside their frozen budgets; model, reasoning, CLI, browser, input, evaluator, and runner hashes were checked against records. The evaluator's separate nine-input validation passed. Repository formatting, lint, static checks, guide checks, and the packaged-CLI regression passed; the regression tested the exact archive above.
