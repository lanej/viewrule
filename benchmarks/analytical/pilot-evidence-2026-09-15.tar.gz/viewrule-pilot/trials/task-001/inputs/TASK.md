Review and, where necessary, repair this shipping comparison UI. Preserve its
data and behavior. Show complete service names, USD-per-parcel prices, delivery
days, on-time rates, and reporting context. When twelve services are available,
at least eight complete alternatives must be visible initially. If only four
exist, show all four. Preserve comparison identities across 1280×900 and
3840×2160 viewports. Related numeric values must stay within 150 CSS pixels.
Retain readable type and check the state after applying the filter. Explain
defects with evidence, repair the application source, and verify the result.
Do not change requirements or detector configuration to obtain a pass.

Edit only index.html. Keep all tool and requirement files unchanged.
