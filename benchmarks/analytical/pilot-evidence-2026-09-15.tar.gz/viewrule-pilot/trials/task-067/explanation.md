Repaired [index.html](/task/index.html:70) only.

**Defect:** A ≥2000px CSS rule hid “Beacon Ground / Economy,” changing comparison identities. At 4K, 12 services became 11; four became three, including after filtering. [Before evidence](/tmp/shipping-before.json)

**Fix:** Removed that rule. Data, filter behavior, and all other files remain unchanged.

**Verification:** Eight cases passed across 1280×900 and 3840×2160, before and after filtering:

- All 12 alternatives fit initially; the four-service fixture shows all four.
- Complete names, USD-per-parcel prices, delivery days, on-time rates, and reporting context remain visible.
- Type remains 16px; adjacent numeric centers are at most 128.8 CSS pixels apart.
- No overflow or JavaScript errors; the supplied detector reported no findings.

[Verification report](/tmp/shipping-verification.json) · [Detector output](/tmp/shipping-detector.json)

No unresolved defects found within scope. Verification used local Chromium; four-service availability was simulated without changing application data.
