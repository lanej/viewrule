Repaired only [index.html](/task/index.html).

**Defects fixed:** numeric values were 223px apart, headings weren’t aligned with their numbers, and filtering gave no visible confirmation. Numeric centers are now 104px apart; the entire numeric text group spans 148px. Added accessible filter feedback.

**Verified:** all eight combinations passed—12/four services, both requested viewports, before/after filtering. All available rows are complete and visible, with unchanged identities, values, reporting context, and 16px type. The supplied detector reported no findings; all other files remained unchanged.

Evidence: [before](/tmp/shipping-before-1280-initial.png), [after filtering](/tmp/shipping-after-12-1280-filtered.png), [verification results](/tmp/shipping-verification.json).

Limitations: local Chromium only; four services were tested through a temporary browser-response fixture. No checkpoint/config/rules files were present to run additional configured checks.
