export default async ({ page, checkpoint }) => { if (checkpoint.name === "filtered") await page.locator("#apply-filter").click(); };
