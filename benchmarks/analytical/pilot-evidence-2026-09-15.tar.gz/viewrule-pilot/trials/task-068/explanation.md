Repaired only [index.html](/task/index.html:70).

**Defect:** A media query hid Beacon Ground / Economy (`carrier-2`) above 2000px. Desktop showed 12 services; 3840×2160 showed 11, including after filtering. The [baseline report](/task/.ui-review/runs/2026-09-15T19-05-50-469Z-0f6849ad/index.html) recorded four `identities` errors under DR-006/007.

**Repair:** Removed the hiding rule. Data, service order, filter behavior, requirements, and detector configuration remain unchanged.

**Verification:**

- [Configured checks pass](/task/.ui-review/runs/2026-09-15T19-07-42-373Z-8f66a3ff/index.html): zero errors or warnings.
- Both viewports show all 12 complete services initially and after filtering.
- A temporary browser-only four-service fixture shows all four in both states.
- Full names, USD-per-parcel prices, delivery days, on-time percentages, and dated reporting context remain visible.
- Type remains **16px**; maximum adjacent numeric text gap is **102.4 CSS pixels**, below 150.
- Inspected overview screenshots and original-size comparison details. [Additional measurements](/tmp/parcel-verification.json).

Retained the bounded table following Viewrule v1.2.0 P-001/P-004 and its recognition/Tufte practitioner guidance.

**Limits:** Four-service availability was simulated; the application supplies twelve. Accessibility auditing is disabled in the unchanged configuration. Synthetic data accuracy was not independently validated.
