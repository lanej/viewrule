Repaired only [index.html](/task/index.html:42).

**Defects found** ([baseline evidence](/tmp/shipping-before-evidence.json)):

- A media rule hid **Beacon Ground / Economy** at 3840px: 11 alternatives versus 12 at 1280px.
- Price and on-time values were 223.2px apart center-to-center, exceeding 150px.

**Changes:** Removed the hiding rule, narrowed the table, and aligned numeric headers. Data, filter behavior, complete names, USD-per-parcel context, delivery days, rates, reporting date, and 16px type remain intact.

**Verified:** [Eight Playwright scenarios passed](/tmp/shipping-verification.json), covering both requested viewports before and after filtering:

- All **12/12** alternatives fully visible.
- All **4/4** visible in an isolated four-service fixture.
- Identities and values preserved during live resizing.
- Maximum numeric separation **143.2px**; no clipping, horizontal overflow, or JavaScript errors.

[Verified filtered screenshot](/tmp/shipping-verified-12-1280-filtered.png)

**Limitations:** Four-service coverage used a browser-only fixture. No configured detector files were available; verification used local Chromium/Playwright. Requirements and assistance files were unchanged.
