Repaired only [index.html](/task/index.html:59).

**Defects and fixes**

- Filtering hid the reporting date and “USD per parcel” context. Removed that hiding rule.
- Price-to-on-time values were 223.2px apart. Tightened and aligned numeric columns, reducing maximum separation to **147.2px**.

**Verification**

Eight Playwright cases passed across **1280×900** and **3840×2160**, before and after filtering:

- All **12 complete services** visible initially; all four visible with a four-service fixture.
- Full names, prices, delivery days, on-time rates, and reporting context visible.
- Identities, values, and filter behavior preserved.
- **16px** type retained; no clipping, horizontal overflow, or browser errors.

Evidence: [before](/tmp/shipping-before-1280-filtered.png), [after](/tmp/shipping-verified-12-1280-filtered.png), [verification report](/tmp/shipping-verification.json).

**Limitations:** Four-service availability was simulated in-browser. Configured checkpoint files were absent, so verification used independent Playwright checks. No requirement or tool files were changed.
