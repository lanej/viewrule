Fixed one defect in [index.html](/task/index.html:70): applying the filter hid the quote date and “USD per parcel” context. Removed only that CSS rule; data, identities, layout, and filter logic remain unchanged.

Evidence: filtered state [before](/tmp/parcel-before-12-1280-filtered.png) → [after](/tmp/parcel-after-12-1280-filtered.png).

**Verification passed** at 1280×900 and 3840×2160, before and after filtering:

- All 12 complete services visible initially; four-service fixture shows all four.
- Full names, prices, delivery days, on-time rates, and reporting context visible.
- Identical service keys and values across viewports.
- Readable 16px type; adjacent numeric columns 112 CSS pixels apart, below 150px.
- No browser errors; Impeccable detector reported no findings.

[Verification results](/tmp/parcel-verification.json) · [Detector output](/tmp/parcel-detector.json)

Only `index.html` was edited; requirements and tools were unchanged. No unresolved defects in tested states. Limitation: four-service coverage used a browser-only fixture; the application’s twelve-service dataset remains intact.
